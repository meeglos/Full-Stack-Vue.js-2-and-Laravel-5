# Vuebnb Prototype

Source code for the "Vuebnb prototype" from the book *Full Stack Vue Web Development: Vue.js, Vuex and Laravel* by Anthony Gore, published by Packt Publishing.

## Chapters

This repository has the required code for **chapter 2 of the book only**. If you're looking for the code for chapters 3 to 11, check [this repository](https://github.com/fsvwd/vuebnb).

## Cloning the code

To clone this code on your local machine, use the following command:

```bash
$ git clone https://github.com/fsvwd/vuebnb-project.git
```

* * *

*Loving Vue.js? Join [Vue.js Developers](https://vuejsdevelopers.com), a community of thousands of web developers passionate about learning and building with Vue.js.*

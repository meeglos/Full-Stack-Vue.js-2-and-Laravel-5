<?php

Route::get('/listing/{listing}', 'ListingController@get_listing_api');
